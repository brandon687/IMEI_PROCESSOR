<?php include('header.htm'); ?>
<h2>IMEI Services</h2>
<a href="imeiservices.php" target="_blank" class="link">IMEI Services</a> <br /><br />
<a href="placeimeiorder.php" target="_blank" class="link">Place IMEI Order</a> <br /><br />
<a href="getimeiorder.php" target="_blank" class="link">Get IMEI Order</a> <br /><br />

<h2>File Services</h2>
<a href="fileservices.php" target="_blank" class="link">File Services</a> <br /><br />
<a href="placefileorder.php" target="_blank" class="link">Place File Order</a> <br /><br />
<a href="getfileorder.php" target="_blank" class="link">Get File Order</a> <br /><br />

<h2>Server Services</h2>
<a href="serverservices.php" target="_blank" class="link">Server Services</a> <br /><br />
<a href="placeserverorder.php" target="_blank" class="link">Place Server Order</a> <br /><br />
<a href="getserverorder.php" target="_blank" class="link">Get Server Order</a> <br /><br />

<h2>Additional Services</h2>
<?php include 'services.php'; ?>
<?php include('footer.htm'); ?>